#ifndef ASKISI1C___CPP_PROJECT_CARD_H_
#define ASKISI1C___CPP_PROJECT_CARD_H_

#include <string>
using namespace std;

class Card
{
    string name;
    int cost;
    bool isTrapped;
};




#endif //ASKISI1C___CPP_PROJECT_CARD_H_
