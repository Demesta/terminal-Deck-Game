
#ifndef CPP_PROJECT__ITEM_H_
#define CPP_PROJECT__ITEM_H_

#include "Card.h"


class Item : public GreenCard
{

};


#endif //CPP_PROJECT__ITEM_H_
