#include "Card.h"

class BlackCard : public Card
{
    bool isReleaved;
};

