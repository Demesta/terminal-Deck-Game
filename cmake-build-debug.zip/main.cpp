#include <iostream>

int main()
{

}
