
#ifndef CPP_PROJECT__FOLLOWER_H_
#define CPP_PROJECT__FOLLOWER_H_
#include "GreenCard.h"

class Follower : public GreenCard
{

};

#endif //CPP_PROJECT__FOLLOWER_H_
