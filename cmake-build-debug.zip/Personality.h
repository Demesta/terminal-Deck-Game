#ifndef CPP_PROJECT__PERSONALITY_H_
#define CPP_PROJECT__PERSONALITY_H_

#include "BlackCard.h"

class Personality : public BlackCard
{
int attack;
int defence;
int honour;
bool isDead;
};



#endif //CPP_PROJECT__PERSONALITY_H_
